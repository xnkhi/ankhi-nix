"use strict";
(() => {
  // src/connectors/playmoss.ts
  Connector.playerSelector = "#footer-player";
  Connector.artistTrackSelector = "#footer-player li.playing a";
  Connector.playButtonSelector = "button.play";
})();
