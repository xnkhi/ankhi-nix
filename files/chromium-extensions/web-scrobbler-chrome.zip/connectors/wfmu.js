"use strict";
(() => {
  // src/connectors/wfmu.ts
  Connector.playerSelector = ".player-section";
  Connector.artistSelector = ".playing > .segment-artist";
  Connector.trackSelector = ".playing > .segment-title";
  Connector.playButtonSelector = "#play-buttton";
})();
