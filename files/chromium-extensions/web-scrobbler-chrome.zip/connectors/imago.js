"use strict";
(() => {
  // src/connectors/imago.ts
  Connector.playerSelector = ".now-play";
  Connector.artistTrackSelector = "#current-track";
  Connector.playButtonSelector = ".play-icon.stop";
})();
