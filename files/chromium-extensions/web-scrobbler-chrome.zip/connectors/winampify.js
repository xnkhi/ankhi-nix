"use strict";
(() => {
  // src/connectors/winampify.ts
  Connector.playerSelector = "#winamp-meta";
  Connector.playButtonSelector = "#main-window .play";
  Connector.albumSelector = "#winamp-meta-album";
  Connector.artistSelector = "#winamp-meta-artist";
  Connector.trackSelector = "#winamp-meta-title";
})();
