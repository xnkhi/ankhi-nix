"use strict";
(() => {
  // src/connectors/fmspins.ts
  Connector.playerSelector = "#main";
  Connector.artistSelector = "#current-spins .list-group-item.spin:first-child .artist a";
  Connector.trackSelector = "#current-spins .list-group-item.spin:first-child .track a";
  Connector.trackArtSelector = "#current-spins .list-group-item.spin:first-child";
  Connector.playButtonSelector = ".actions .fa-play";
})();
