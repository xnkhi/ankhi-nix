"use strict";
(() => {
  // src/connectors/roxx.ts
  Connector.playerSelector = "#rj-player";
  Connector.artistSelector = "#trackInfo .artist";
  Connector.trackSelector = "#trackInfo .track";
  Connector.playButtonSelector = ".jp-play";
})();
