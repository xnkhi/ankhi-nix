"use strict";
(() => {
  // src/connectors/nugs.ts
  Connector.playerSelector = "#audio-player.audio-player";
  Connector.pauseButtonSelector = "#player-play-pause";
  Connector.trackSelector = "#player-title";
  Connector.artistSelector = "#player-artist-name";
  Connector.albumSelector = "#player-meta-info .player-venue";
  Connector.currentTimeSelector = "#player-time-current";
  Connector.remainingTimeSelector = "#player-time-remaining";
  Connector.trackArtSelector = "#player-cover-image";
})();
