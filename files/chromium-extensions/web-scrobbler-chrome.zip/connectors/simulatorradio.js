"use strict";
(() => {
  // src/connectors/simulatorradio.ts
  Connector.playerSelector = ".container.player-wrap";
  Connector.trackArtSelector = ".record-img";
  Connector.artistSelector = ".song>.Artist";
  Connector.trackSelector = ".song>.Title";
  Connector.playButtonSelector = ".playpause > .fa-play";
})();
