"use strict";
(() => {
  // src/connectors/apt-get-tunes.ts
  Connector.useMediaSessionApi();
  Connector.playerSelector = "#player";
})();
