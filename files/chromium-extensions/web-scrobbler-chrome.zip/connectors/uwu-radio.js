"use strict";
(() => {
  // src/connectors/uwu-radio.ts
  Connector.useMediaSessionApi();
  Connector.playerSelector = "#player";
})();
