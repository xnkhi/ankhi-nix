"use strict";
(() => {
  // src/connectors/hillydilly.ts
  Connector.playerSelector = ".appPlayer";
  Connector.artistTrackSelector = ".appPlayer__title";
  Connector.playButtonSelector = ".appPlayer__play";
})();
