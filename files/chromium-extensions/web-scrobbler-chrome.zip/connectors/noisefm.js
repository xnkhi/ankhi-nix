"use strict";
(() => {
  // src/connectors/noisefm.ts
  Connector.artistTrackSelector = ".progress > span";
  Connector.playButtonSelector = "a.play";
  Connector.playerSelector = ".controls";
})();
