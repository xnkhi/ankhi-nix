"use strict";
(() => {
  // src/connectors/ambientsleepingpill.ts
  Connector.playerSelector = "#player";
  Connector.artistSelector = "#trackartist";
  Connector.trackSelector = "#tracktitle";
  Connector.playButtonSelector = "#play";
})();
