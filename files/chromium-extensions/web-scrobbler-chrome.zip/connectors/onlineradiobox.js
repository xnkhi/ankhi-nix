"use strict";
(() => {
  // src/connectors/onlineradiobox.ts
  Connector.playerSelector = [".player", "body > .station"];
  Connector.artistTrackSelector = "#top_player_track";
  Connector.playButtonSelector = ".player .b-play";
})();
