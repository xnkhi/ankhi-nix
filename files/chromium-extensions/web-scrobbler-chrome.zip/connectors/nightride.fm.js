"use strict";
(() => {
  // src/connectors/nightride.fm.ts
  Connector.playerSelector = "body";
  Connector.artistTrackSelector = "#nowplaying";
  Connector.playButtonSelector = "#playerPlay";
})();
