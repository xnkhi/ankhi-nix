"use strict";
(() => {
  // src/connectors/rozhlas.ts
  Connector.playerSelector = "#block-live-player";
  Connector.artistTrackSelector = "#cro-box-schedule-player-playlist > div > div > div > p > a > strong";
  Connector.playButtonSelector = ".is-paused";
})();
