"use strict";
(() => {
  // src/connectors/jetsetradio.live.ts
  Connector.artistTrackSelector = "#programInformationText";
  Connector.playerSelector = "#programInformationText";
})();
