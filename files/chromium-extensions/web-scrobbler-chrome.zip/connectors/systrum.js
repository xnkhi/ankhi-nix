"use strict";
(() => {
  // src/connectors/systrum.ts
  Connector.playerSelector = ".right_side_scroll";
  Connector.trackSelector = ".now_playing h3";
  Connector.artistSelector = ".now_playing h2";
  Connector.pauseButtonSelector = '.now_playing button.play_btn[data-active="1"]';
})();
