"use strict";
(() => {
  // src/connectors/gbs.fm.ts
  Connector.playerSelector = "#metadata";
  Connector.artistSelector = "#metadata a:nth-child(1)";
  Connector.trackSelector = "#metadata a:nth-child(3)";
  Connector.currentTimeSelector = "#songPosition";
})();
