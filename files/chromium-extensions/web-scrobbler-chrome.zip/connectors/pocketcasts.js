"use strict";
(() => {
  // src/connectors/pocketcasts.ts
  Connector.playerSelector = ".player-controls";
  Connector.artistSelector = ".podcast-title";
  Connector.trackSelector = ".episode-title";
  Connector.playButtonSelector = ".play_button";
  Connector.currentTimeSelector = ".current-time";
  Connector.remainingTimeSelector = ".time-remaining";
  Connector.trackArtSelector = ".player-image img";
  Connector.isPodcast = () => true;
})();
