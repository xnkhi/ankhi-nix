"use strict";
(() => {
  // src/connectors/bollerwagen.ts
  Connector.playerSelector = ".start-player-header";
  Connector.artistSelector = ".webplayer-artist";
  Connector.trackSelector = ".webplayer-title";
  Connector.pauseButtonSelector = ".jp-state-playing";
})();
