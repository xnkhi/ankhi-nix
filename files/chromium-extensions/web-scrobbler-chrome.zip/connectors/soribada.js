"use strict";
(() => {
  // src/connectors/soribada.ts
  Connector.playerSelector = "#footer .player";
  Connector.artistSelector = ".info .pado_tit_wrap span:first-child";
  Connector.trackSelector = ".pado_tit_wrap strong:first";
  Connector.currentTimeSelector = "#progress .now";
  Connector.durationSelector = "#progress .total";
  Connector.pauseButtonSelector = "#controller .pause";
  Connector.trackArtSelector = "#playerWrap #cover img";
})();
