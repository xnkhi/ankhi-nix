"use strict";
(() => {
  // src/connectors/radio-italia.ts
  Connector.playerSelector = ".radio-info";
  Connector.artistSelector = ".now-playing .artist";
  Connector.trackSelector = ".now-playing .track";
  Connector.playButtonSelector = ".icon-play";
})();
