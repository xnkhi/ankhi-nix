"use strict";
(() => {
  // src/connectors/trackerhub.ts
  Connector.useMediaSessionApi();
  Connector.playerSelector = "#player";
})();
