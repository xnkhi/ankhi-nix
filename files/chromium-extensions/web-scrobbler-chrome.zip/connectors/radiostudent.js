"use strict";
(() => {
  // src/connectors/radiostudent.ts
  Connector.playerSelector = "#icecast_list";
  Connector.artistTrackSelector = "#icecast_list > ul > li > p";
})();
