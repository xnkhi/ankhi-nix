"use strict";
(() => {
  // src/connectors/jsososo.ts
  Connector.playerSelector = ".player-container";
  Connector.artistSelector = ".player-song-singer";
  Connector.trackSelector = ".player-song-title";
  Connector.timeInfoSelector = ".play-time";
  Connector.trackArtSelector = ".progress-cover";
  Connector.playButtonSelector = ".icon-bofang";
})();
