"use strict";
(() => {
  // src/connectors/chillhop.ts
  Connector.playerSelector = "#player-controlls";
  Connector.pauseButtonSelector = ".fa-pause";
  Connector.durationSelector = ".track-length";
  Connector.artistSelector = ".jp-artists";
  Connector.trackSelector = ".jp-title";
})();
